// Anthony Fillmore
// CS330 Week 7 Final Project
// 2/25/2024

#include <GLEW/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <glm/glm/glm.hpp>
#include <glm/glm/gtc/matrix_transform.hpp>
#include <glm/glm/gtx/transform.hpp>
#include <glm/glm/gtc/type_ptr.hpp>
#include <SOIL2/stb_image.h>      // Image loading Utility functions

#include <camera.h> // Camera class

#include <cmath>
#include <vector>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

using namespace std;

int width, height;
GLuint mugVBO, mugVAO, mugEBO; // triangle VAO variables
GLuint cylinderVAO, cylinderVBO, cylinderEBO; // globals for candle cylinder
GLuint planeVAO, planeVBO, planeEBO; // globals for plane variables
GLuint leftBookVAO, leftBookVBO, leftBookEBO; // globals for plane variables
GLuint rightBookVAO, rightBookVBO, rightBookEBO; // globals for plane variables
GLuint cubeVAO, cubeVBO, cubeEBO; // globals for cube variables
GLuint topTorusVAO, topTorusVBO, topTorusEBO; // Global variables for the top horizontal torus segment
GLuint handleTorusVAO, handleTorusVBO, handleTorusEBO; // Global variables for the vertical horizontal torus segment
GLuint nVertices;    // Number of indices of the mesh
int numVerticesTorus; // vertices for torus
float camX, camY, camZ; // view or camera location (x,y,z)
float triLocX, triLocY, triLocZ; // triangle location (x,y,z)
GLuint mvLoc, projLoc; // mvp uniform reference variables
float aspectRatio; // for p matrix aspect ratio
glm::mat4 pMat, vMat, mMat, mvMat; // mvp variables
GLuint shaderProgram; // for compiled shaders
bool isPerspective = true; // Start with perspective projection

// Array for triangle rotations
glm::float32 triRotations[] = { 0.0f, 60.0f, 120.0f, 180.0f, 240.0f, 300.0f };

// Unnamed namespace
namespace
{
	const char* const WINDOW_TITLE = "Afillmore Week 7 Final Project Scene!!!"; // Macro for window title

	// Variables for window width and height
	const int WINDOW_WIDTH = 1024;
	const int WINDOW_HEIGHT = 768;

	// Main GLFW window
	GLFWwindow* gWindow = nullptr;

	// Texture
	glm::vec2 gUVScale(5.0f, 5.0f);
	GLint gTexWrapMode = GL_REPEAT;

	// Shader program
	GLuint gProgramId;

	// camera - starting position
	Camera gCamera(glm::vec3(-0.1f, 0.25f, 3.50f));
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// timing
	float gDeltaTime = 0.0f; // time between current frame and last frame
	float gLastFrame = 0.0f;
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 */
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);

/* Vertex Shader Source Code - With light added */
const GLchar* vertexShaderSource = GLSL(440,
	layout(location = 0) in vec3 position;
	layout(location = 1) in vec3 normal;
	layout(location = 2) in vec2 textureCoordinate;

	out vec3 vertexNormal;
	out vec3 vertexFragmentPos;
	out vec2 vertexTextureCoordinate;
	out vec3 keyLightPosView; // Pass this to the fragment shader
	out vec3 fillLightPosView;

	uniform mat4 model;
	uniform mat4 view;
	uniform mat4 projection;
	uniform vec3 keyLightPos; // Light position in world space
	uniform vec3 fillLightPos;

void main() {
	gl_Position = projection * view * model * vec4(position, 1.0f);
	vertexFragmentPos = vec3(model * vec4(position, 1.0f));
	vertexNormal = mat3(transpose(inverse(model))) * normal;
	vertexTextureCoordinate = textureCoordinate;

	// Transform light positions into view space
	keyLightPosView = vec3(view * vec4(keyLightPos, 1.0));
	fillLightPosView = vec3(view * vec4(fillLightPos, 1.0));
}
);

/* Fragment Shader Source Code --- Updated to texturing and lighting*/
const GLchar* fragmentShaderSource = GLSL(440,
	in vec3 vertexNormal;
	in vec3 vertexFragmentPos;
	in vec2 vertexTextureCoordinate;

	out vec4 fragmentColor;

	uniform mat4 view;
	uniform vec3 viewPosition;
	uniform sampler2D uTexture;
	uniform vec2 uvScale;

	// Light properties
	uniform vec3 keyLightPos;
	uniform vec3 keyLightColor;
	uniform vec3 fillLightPos;
	uniform vec3 fillLightColor;
	uniform vec3 specularLightPos;
	uniform vec3 specularLightColor;

void main() {
	// Ambient Lighting
	float ambientStrength = 0.4f;
	vec3 ambientKey = ambientStrength * keyLightColor;
	vec3 ambientFill = ambientStrength * fillLightColor;
	vec3 ambient = ambientKey + ambientFill;

	// Initialize diffuse and specular components
	vec3 diffuse = vec3(0.0);
	vec3 specular = vec3(0.0);
	float specularStrength = 0.8f;
	float shininess = 32.0f;

	// Transform light positions into view space
	vec3 keyLightPosView = vec3(view * vec4(keyLightPos, 1.0));
	vec3 fillLightPosView = vec3(view * vec4(fillLightPos, 1.0));

	// Normalized vectors
	vec3 norm = normalize(vertexNormal);
	vec3 viewDir = normalize(viewPosition - vertexFragmentPos);

	// Key Light Calculations using view space positions
	vec3 keyDir = normalize(keyLightPosView - vertexFragmentPos);
	float keyDiff = max(dot(norm, keyDir), 0.0);
	diffuse += keyDiff * keyLightColor;

	vec3 keyReflectDir = reflect(-keyDir, norm);
	float keySpec = pow(max(dot(viewDir, keyReflectDir), 0.0), shininess);
	specular += specularStrength * keySpec * keyLightColor;

	// Fill Light Calculations using view space positions
	vec3 fillDir = normalize(fillLightPosView - vertexFragmentPos);
	float fillDiff = max(dot(norm, fillDir), 0.0);
	diffuse += fillDiff * fillLightColor * 0.5; // Reduced intensity for fill light

	vec3 fillReflectDir = reflect(-fillDir, norm);
	float fillSpec = pow(max(dot(viewDir, fillReflectDir), 0.0), shininess);
	specular += specularStrength * fillSpec * fillLightColor * 0.75; // Reduced intensity for fill light

	// Specular Light Calculations using view space positions
	vec3 specularLightPosView = vec3(view * vec4(specularLightPos, 1.0));
	vec3 specDir = normalize(specularLightPosView - vertexFragmentPos);
	vec3 specReflectDir = reflect(-specDir, norm);
	float specDot = max(dot(viewDir, specReflectDir), 0.0);
	float spec = pow(specDot, shininess);
	specular += specularStrength * spec * specularLightColor;

	// Combine results with texture color
	vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);
	vec3 result = (ambient + diffuse + specular) * textureColor.xyz;

	// Output the final color
	fragmentColor = vec4(result, 1.0);
}
);

/* GLSL Error Checking Definitions */
void PrintShaderCompileError(GLuint shader)
{
	int len = 0;
	int chWritten = 0;
	char* log;
	glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &len);
	if (len > 0)
	{
		log = (char*)malloc(len);
		glGetShaderInfoLog(shader, len, &chWritten, log);
		cout << "Shader Compile Error: " << log << endl;
		free(log);
	}
}

// Method that prints an error message if the shader link fails
void PrintShaderLinkingError(int prog)
{
	int len = 0;
	int chWritten = 0;
	char* log;
	glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &len);
	if (len > 0)
	{
		log = (char*)malloc(len);
		glGetShaderInfoLog(prog, len, &chWritten, log);
		cout << "Shader Linking Error: " << log << endl;
		free(log);
	}
}

// Method that prints openGL errors to the screen
bool IsOpenGLError()
{
	bool foundError = false;
	int glErr = glGetError();
	while (glErr != GL_NO_ERROR)
	{
		cout << "glError: " << glErr << endl;
		foundError = true;
		glErr = glGetError();
	}
	return foundError;
}

/* GLSL Error Checking Definitions End Here */

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it - more texture stuff
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
	for (int j = 0; j < height / 2; ++j)
	{
		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;

		for (int i = width * channels; i > 0; --i)
		{
			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
	int width, height, channels;
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
	if (image)
	{
		// may need this...
		flipImageVertically(image, width, height, channels);

		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (channels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (channels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			cout << "Not implemented to handle image with " << channels << " channels" << endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		return true;
	}

	// Error loading the image
	return false;
}

// method to destroy texture after usage
void UDestroyTexture(GLuint textureId)
{
	glGenTextures(1, &textureId);
}

/*Draw Primitive(s)*/
void draw(GLFWwindow* window, double currentTime, GLuint textureIDs[]) {

	// Set clear color to grey for background
	glClearColor(0.6f, 0.6f, 0.6f, 1.0f);

	// Enable z-depth
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL); // Use LEQUAL to handle coplanar polygons

	// clear frame and z buffer
	glClear(GL_DEPTH_BUFFER_BIT);
	glClear(GL_COLOR_BUFFER_BIT);

	// Build Perspective matrix
	glfwGetFramebufferSize(window, &width, &height);
	aspectRatio = (float)width / (float)height;

	// decision for what perspective should be used 
	if (isPerspective) {
		pMat = glm::perspective(1.0472f, aspectRatio, 0.1f, 100.0f);
	}
	else {
		// Ortho projection
		float scale = 10.0f;
		pMat = glm::ortho(-aspectRatio * scale, aspectRatio * scale, -scale, scale, 0.1f, 1000.0f);
	}

	// Set the shader to be used
	glUseProgram(gProgramId);

	// setup camera view matrix
	vMat = gCamera.GetViewMatrix();

	// Retrieves and passes transform matrices to the Shader program
	GLint modelLoc = glGetUniformLocation(gProgramId, "model");
	GLint viewLoc = glGetUniformLocation(gProgramId, "view");
	GLint projLoc = glGetUniformLocation(gProgramId, "projection");

	// Pass the camera's position to the shader for lighting calculations
	GLint viewPosLoc = glGetUniformLocation(gProgramId, "viewPosition");
	glUniform3fv(viewPosLoc, 1, glm::value_ptr(gCamera.Position));

	// Set the light's properties in world space
	glm::vec3 keyLightPosition = glm::vec3(-3.0f, 5.0f, 4.0f); // Adjusted for front, above and slightly from the left of the scene
	glm::vec3 fillLightPosition = glm::vec3(3.0f, 3.0f, 2.0f); // Positioned to soften shadows, less intense
	glm::vec3 specularLightPosition = glm::vec3(-3.0f, 0.0f, 5.0f); // specular light

	// Transform light positions into view space
	glm::vec3 keyLightPosView = glm::vec3(vMat * glm::vec4(keyLightPosition, 1.0));
	glm::vec3 fillLightPosView = glm::vec3(vMat * glm::vec4(fillLightPosition, 1.0));
	glm::vec3 specularLightPosView = glm::vec3(vMat * glm::vec4(specularLightPosition, 1.0));

	// Pass the light positions to the shader
	GLint keyLightPosLoc = glGetUniformLocation(gProgramId, "keyLightPos");
	GLint fillLightPosLoc = glGetUniformLocation(gProgramId, "fillLightPos");
	GLint specularLightPosLoc = glGetUniformLocation(gProgramId, "specularLightPos");

	glUniform3fv(keyLightPosLoc, 1, glm::value_ptr(keyLightPosView));
	glUniform3fv(fillLightPosLoc, 1, glm::value_ptr(fillLightPosView));
	glUniform3fv(specularLightPosLoc, 1, glm::value_ptr(specularLightPosView));

	// Set the light colors
	glUniform3f(glGetUniformLocation(gProgramId, "keyLightColor"), 1.0f, 0.9f, 0.8f); // Warm white key light
	glUniform3f(glGetUniformLocation(gProgramId, "fillLightColor"), 0.6f, 0.6f, 0.6f); // Dimmer white fill light for soft shadows
	glUniform3f(glGetUniformLocation(gProgramId, "specularLightColor"), 1.0f, 1.0f, 1.0f); // Bright white specular light

	// Bind the texture for the plane
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, textureIDs[2]);

	//////////////////////////////
	// Bottom plane creation
	glBindVertexArray(planeVAO);

	mMat = glm::mat4(1.0f); // Use an identity matrix for model transformations

	// Translate the plane to be at the level where the cup should rest
	mMat = glm::translate(mMat, glm::vec3(0.0f, -1.95f, 0.0f));
	mvMat = vMat * mMat; // Calculate the combined model-view matrix
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(mvMat));

	// draw -  6 indices for the 2 triangles
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, 0);

	// Unbind the VAO
	glBindVertexArray(0);

	//////////////////////////
	// Cup shape
	// bind textures on corresponding texture units -- Needed for textures
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, textureIDs[1]);

	glBindVertexArray(mugVAO); // Activate VAO

	// Set up transformations for the mug
	mMat = glm::translate(glm::mat4(1.0f), glm::vec3(triLocX - 1.60f, triLocY - 1.0f, triLocZ));
	mMat = glm::rotate(mMat, glm::radians(0.0f), glm::vec3(3.0f, 0.0f, 0.0f));
	mvMat = vMat * mMat;

	// Pass mvMat and pMat to the shader
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(vMat));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));

	glDepthFunc(GL_LEQUAL);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); // Change to fill polygons

	// draw the mug using indices
	glDrawElements(GL_TRIANGLES, 6336, GL_UNSIGNED_SHORT, 0);

	//////////////////////////////////
	// Torus for handle
	// Bind the texture for the torus
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, textureIDs[1]);

	glBindVertexArray(handleTorusVAO);
	//mMat = glm::scale(mMat, glm::vec3(0.75f, 0.85f, 0.85)); // Scale the torus
	mMat = glm::rotate(mMat, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.00f)); // Rotate to make it vertical
	mMat = glm::translate(mMat, glm::vec3(triLocX + 0.0f, triLocY + 0.95f, triLocZ));
	mMat = glm::scale(mMat, glm::vec3(0.75f, 0.85f, 2.0f)); // Scale the torus
	mvMat = vMat * mMat;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));

	// Draw the torus segment
	glDrawElements(GL_TRIANGLE_STRIP, numVerticesTorus, GL_UNSIGNED_SHORT, 0);

	// unbind VAO
	glBindVertexArray(0);

	//////////////////////////////
	// draw top of mug torus
	glBindVertexArray(topTorusVAO);

	// different texture
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, textureIDs[0]);

	mMat = glm::scale(glm::mat4(1.0f), glm::vec3(1.0f, 0.50f, 1.0)); // Scale the torus
	mMat = glm::rotate(mMat, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
	mMat = glm::translate(mMat, glm::vec3(triLocX - 1.59, triLocY, triLocZ + 0.25f));
	mvMat = vMat * mMat;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));

	// Draw the top torus segment
	glDrawElements(GL_TRIANGLE_STRIP, numVerticesTorus, GL_UNSIGNED_SHORT, 0);

	// unbind VAO
	glBindVertexArray(0);

	// Setup texturizing
	// We set the texture as texture unit 0
	GLint uvScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
	glm::vec2 uvScaleValue(1.0f, 1.0f);
	glUniform2fv(uvScaleLoc, 1, glm::value_ptr(uvScaleValue));

	/////////////////////////////////
	// Draw the left page of the book
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, textureIDs[6]);
	glBindVertexArray(leftBookVAO);
	glm::mat4 leftPageModel = glm::mat4(1.0f);
	leftPageModel = glm::translate(leftPageModel, glm::vec3(-0.1f, -2.1f, -2.0f));
	leftPageModel = glm::scale(leftPageModel, glm::vec3(4.5f, 4.5f, 4.5f)); // Scale up the page by 4.5 times
	leftPageModel = glm::rotate(leftPageModel, glm::radians(-25.0f), glm::vec3(0.0f, 1.0f, 0.0f)); // Rotate to open the book
	mvMat = vMat * leftPageModel;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, 0); // 6 indices for 2 triangles
	glBindVertexArray(0); // Unbind the VAO

	//////////////////////////////////
	// Draw the right page of the book
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, textureIDs[3]);
	glBindVertexArray(rightBookVAO);
	glm::mat4 rightPageModel = glm::mat4(1.0f);
	rightPageModel = glm::translate(rightPageModel, glm::vec3(0.1f, -2.1f, -2.0f)); //
	rightPageModel = glm::scale(rightPageModel, glm::vec3(4.5f, 4.5f, 4.5f)); // Scale up the page by 4.5 times
	rightPageModel = glm::rotate(rightPageModel, glm::radians(25.0f), glm::vec3(0.0f, 1.0f, 0.0f)); // Rotate to open the book
	mvMat = vMat * rightPageModel;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, 0); // 6 indices for 2 triangles
	glBindVertexArray(0); // Unbind the VAO

	//////////////////////////////////
	// Draw cube
	glBindVertexArray(cubeVAO);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, textureIDs[4]);
	mMat = glm::mat4(1.0f); // Start with the identity matrix
	mMat = glm::translate(mMat, glm::vec3(1.0f, -1.1f, 0.0f)); // Position the cube at the center
	mMat = glm::scale(mMat, glm::vec3(1.75f, 1.75f, 1.75f)); // Scale the cube up by a factor of 2
	mMat = glm::rotate(mMat, glm::radians(55.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	mvMat = vMat * mMat; // Calculate model-view matrix for the cube
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0); // 36 indices for the 12 triangles
	glBindVertexArray(0);

	////////////////////////////////
	// Draw candle cylinder
	glBindVertexArray(cylinderVAO);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, textureIDs[5]);
	mMat = glm::mat4(1.0f);
	// Position the cylinder above the cube
	mMat = glm::translate(mMat, glm::vec3(1.0f, 0.5f, 0.0f)); // Translate right and up
	mvMat = vMat * mMat;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(mvMat));

	// Draw the candle shape
	glDrawElements(GL_TRIANGLES, 576, GL_UNSIGNED_SHORT, 0);
	glBindVertexArray(0);
}

// Implements the UCreateShaders function

bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
	// Compilation and linkage error reporting
	int success = 0;
	char infoLog[512];

	// Create a Shader program object.
	programId = glCreateProgram();

	// Create the vertex and fragment shader objects
	GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
	GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

	// Retrive the shader source
	glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
	glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

	// Compile the vertex shader, and print compilation errors (if any)
	glCompileShader(vertexShaderId); // compile the vertex shader
	// check for shader compile errors
	glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

		return false;
	}

	glCompileShader(fragmentShaderId); // compile the fragment shader
	// check for shader compile errors
	glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

		return false;
	}

	// Attached compiled shaders to the shader program
	glAttachShader(programId, vertexShaderId);
	glAttachShader(programId, fragmentShaderId);

	glLinkProgram(programId);   // links the shader program
	// check for linking errors
	glGetProgramiv(programId, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

		return false;
	}

	glUseProgram(programId);    // Uses the shader program

	return true;
}

void CreateBookPlane(GLuint& vao, GLuint& vbo, GLuint& ebo, GLfloat bookWidth, GLfloat bookHeight, GLfloat bookDepth, bool isLeftPage) {
	GLfloat normalX = isLeftPage ? -1.0f : 1.0f; // Outward normals on the X-axis for left or right page

	GLfloat planeVertices[] = {
		// Positions                  // Normals            // Texture Coords
		-bookWidth / 2, 0.0f,          bookDepth / 2,    normalX, 0.0f, 0.0f,    0.0f, 0.0f, // Bottom Left
		-bookWidth / 2, bookHeight,    bookDepth / 2,    normalX, 0.0f, 0.0f,    0.0f, 1.0f, // Top Left
		 bookWidth / 2, bookHeight,    bookDepth / 2,    normalX, 0.0f, 0.0f,    1.0f, 1.0f, // Top Right
		 bookWidth / 2, 0.0f,          bookDepth / 2,    normalX, 0.0f, 0.0f,    1.0f, 0.0f  // Bottom Right
	};

	// Define the indices for the plane - 2 triangles
	GLushort planeIndices[] = {
		0, 1, 2, // first triangle
		0, 2, 3  // second triangle
	};

	// Generate and bind the VAO for the plane
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	// Generate and bind the VBO for the plane vertices
	glGenBuffers(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), planeVertices, GL_STATIC_DRAW);

	// Generate and bind the EBO for the plane indices
	glGenBuffers(1, &ebo);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(planeIndices), planeIndices, GL_STATIC_DRAW);

	// Set up the vertex attribute pointers
	// Position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// Normal attribute
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	// Texture coordinate attribute
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);

	// Unbind the VBO and VAO
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

/* Create the plane for our scene */
void CreateBasePlane(GLuint& vao, GLuint& vbo, GLuint& ebo) {
	// Define vertices for a simple quad (2 triangles) to represent the plane
	// Each vertex includes position, normal, and texture coordinates
	GLfloat planeVertices[] = {
		// Positions          // Normals       // Texture Coords
		-15.0f, 0.0f, 10.0f,    0.0f, 1.0f, 0.0f,    0.0f, 0.0f,
		-15.0f, 0.0f, -4.0f,   0.0f, 1.0f, 0.0f,    0.0f, 1.0f,
		15.0f, 0.0f, -4.0f,    0.0f, 1.0f, 0.0f,    1.0f, 1.0f,
		15.0f, 0.0f, 10.0f,     0.0f, 1.0f, 0.0f,    1.0f, 0.0f,
	};

	// Define the indices for the plane - 2 triangles
	GLushort planeIndices[] = {
		0, 1, 2, // first triangle
		0, 2, 3  // second triangle
	};

	// Generate and bind the VAO for the plane
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	// Generate and bind the VBO for the plane vertices
	glGenBuffers(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), planeVertices, GL_STATIC_DRAW);

	// Generate and bind the EBO for the plane indices
	glGenBuffers(1, &ebo);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(planeIndices), planeIndices, GL_STATIC_DRAW);

	// Set up the vertex attribute pointers
	// Position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// Normal attribute
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	// Texture coordinate attribute
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);

	// Unbind the VBO and VAO
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

/* Create cylinder for our candle shape */
void CreateCylinder(GLuint& cylinderVAO, GLuint& cylinderVBO, GLuint& cylinderEBO, float radius, float height, int numSegments) {
	std::vector<GLfloat> vertices;
	std::vector<GLushort> indices;

	// Top circle
	float angleStep = (2.0f * M_PI) / numSegments;
	for (int i = 0; i <= numSegments; ++i) {
		float angle = angleStep * i;

		// Top vertex
		vertices.push_back(radius * cos(angle)); // x
		vertices.push_back(height / 2.0f);       // y
		vertices.push_back(radius * sin(angle)); // z

		// Normals
		vertices.push_back(0.0f); // Normal x
		vertices.push_back(1.0f); // Normal y
		vertices.push_back(0.0f); // Normal z

		// Texture Coordinates
		vertices.push_back(cos(angle) * 0.5f + 0.5f); // u
		vertices.push_back(sin(angle) * 0.5f + 0.5f); // v
	}

	// Bottom circle
	for (int i = 0; i <= numSegments; ++i) {
		float angle = angleStep * i;

		// Bottom vertex
		vertices.push_back(radius * cos(angle)); // x
		vertices.push_back(-height / 2.0f);      // y
		vertices.push_back(radius * sin(angle)); // z

		// Normals
		vertices.push_back(0.0f); // Normal x
		vertices.push_back(-1.0f); // Normal y
		vertices.push_back(0.0f); // Normal z

		// Texture Coordinates
		vertices.push_back(cos(angle) * 0.5f + 0.5f); // u
		vertices.push_back(sin(angle) * 0.5f + 0.5f); // v
	}

	// Side vertices
	for (int i = 0; i <= numSegments; ++i) {
		float angle = angleStep * i;

		// One vertex at the top
		vertices.push_back(radius * cos(angle)); // x
		vertices.push_back(height / 2.0f);       // y
		vertices.push_back(radius * sin(angle)); // z

		// Normal
		vertices.push_back(cos(angle)); // Normal x
		vertices.push_back(0.0f); // Normal y
		vertices.push_back(sin(angle)); // Normal z

		// Texture Coordinates
		vertices.push_back((float)i / numSegments); // u
		vertices.push_back(1.0f); // v

		// One vertex at the bottom
		vertices.push_back(radius * cos(angle)); // x
		vertices.push_back(-height / 2.0f);      // y
		vertices.push_back(radius * sin(angle)); // z

		// Normal
		vertices.push_back(cos(angle)); // Normal x
		vertices.push_back(0.0f); // Normal y
		vertices.push_back(sin(angle)); // Normal z

		// Texture Coordinates
		vertices.push_back((float)i / numSegments); // u
		vertices.push_back(0.0f); // v
	}

	// Index for the top circle
	for (int i = 0; i < numSegments; ++i) {
		indices.push_back(i);
		indices.push_back(i + 1);
		indices.push_back((i + 1) % numSegments);
	}

	// Index for the bottom circle
	int bottomOffset = numSegments + 1;
	for (int i = 0; i < numSegments; ++i) {
		indices.push_back(bottomOffset + i);
		indices.push_back(bottomOffset + (i + 1) % numSegments);
		indices.push_back(bottomOffset + i + 1);
	}

	// Indices for the sides
	int sideOffset = bottomOffset * 2;
	for (int i = 0; i < numSegments; ++i) {
		int current = sideOffset + i * 2;
		int next = sideOffset + ((i + 1) % numSegments) * 2;

		// triangle 1
		indices.push_back(current);
		indices.push_back(next);
		indices.push_back(current + 1);

		// triangle 2
		indices.push_back(next);
		indices.push_back(current + 1);
		indices.push_back(next + 1);
	}

	// Create buffers/arrays
	glGenVertexArrays(1, &cylinderVAO);
	glBindVertexArray(cylinderVAO);

	glGenBuffers(1, &cylinderVBO);
	glBindBuffer(GL_ARRAY_BUFFER, cylinderVBO);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(GLfloat), &vertices[0], GL_STATIC_DRAW);

	glGenBuffers(1, &cylinderEBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cylinderEBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLushort), &indices[0], GL_STATIC_DRAW);

	// Set the vertex attribute pointers
	// Vertex Positions
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)0);
	glEnableVertexAttribArray(0);
	// Vertex Normals
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	// Vertex Texture Coords
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// Unbind the VBO and VAO
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

void CreateCube(GLuint& cubeVAO, GLuint& cubeVBO, GLuint& cubeEBO) {
	// Define the vertices of the cube
	GLfloat vertices[] = {
		// Positions           // Normals           // Texture Coords
	// Back face
	-0.5f, -0.5f, -0.5f,   0.0f, 0.0f, -1.0f,   0.0f, 0.0f, // Bottom-left
	0.5f, -0.5f, -0.5f,   0.0f, 0.0f, -1.0f,   1.0f, 0.0f, // Bottom-right
	0.5f,  0.5f, -0.5f,   0.0f, 0.0f, -1.0f,   1.0f, 1.0f, // Top-right
	-0.5f,  0.5f, -0.5f,   0.0f, 0.0f, -1.0f,   0.0f, 1.0f, // Top-left

	// Front face
	-0.5f, -0.5f,  0.5f,   0.0f, 0.0f,  1.0f,   0.0f, 0.0f, // Bottom-left
	0.5f, -0.5f,  0.5f,   0.0f, 0.0f,  1.0f,   1.0f, 0.0f, // Bottom-right
	0.5f,  0.5f,  0.5f,   0.0f, 0.0f,  1.0f,   1.0f, 1.0f, // Top-right
	-0.5f,  0.5f,  0.5f,   0.0f, 0.0f,  1.0f,   0.0f, 1.0f, // Top-left

	// Left face
	-0.5f,  0.5f,  0.5f,  -1.0f, 0.0f,  0.0f,   1.0f, 0.0f, // Top-right
	-0.5f,  0.5f, -0.5f,  -1.0f, 0.0f,  0.0f,   1.0f, 1.0f, // Top-left
	-0.5f, -0.5f, -0.5f,  -1.0f, 0.0f,  0.0f,   0.0f, 1.0f, // Bottom-left
	-0.5f, -0.5f,  0.5f,  -1.0f, 0.0f,  0.0f,   0.0f, 0.0f, // Bottom-right

	 // Right face
	 0.5f,  0.5f,  0.5f,   1.0f, 0.0f,  0.0f,   1.0f, 0.0f, // Top-right
	 0.5f,  0.5f, -0.5f,   1.0f, 0.0f,  0.0f,   1.0f, 1.0f, // Top-left
	 0.5f, -0.5f, -0.5f,   1.0f, 0.0f,  0.0f,   0.0f, 1.0f, // Bottom-left
	 0.5f, -0.5f,  0.5f,   1.0f, 0.0f,  0.0f,   0.0f, 0.0f, // Bottom-right

	 // Bottom face
	 -0.5f, -0.5f, -0.5f,   0.0f, -1.0f,  0.0f,   0.0f, 1.0f, // Bottom-left
	  0.5f, -0.5f, -0.5f,   0.0f, -1.0f,  0.0f,   1.0f, 1.0f, // Bottom-right
	  0.5f, -0.5f,  0.5f,   0.0f, -1.0f,  0.0f,   1.0f, 0.0f, // Bottom-front
	 -0.5f, -0.5f,  0.5f,   0.0f, -1.0f,  0.0f,   0.0f, 0.0f, // Bottom-back

	 // Top face
	 -0.5f,  0.5f, -0.5f,   0.0f, 1.0f,  0.0f,   0.0f, 1.0f, // Top-left
	  0.5f,  0.5f, -0.5f,   0.0f, 1.0f,  0.0f,   1.0f, 1.0f, // Top-right
	  0.5f,  0.5f,  0.5f,   0.0f, 1.0f,  0.0f,   1.0f, 0.0f, // Top-front
	 -0.5f,  0.5f,  0.5f,   0.0f, 1.0f,  0.0f,   0.0f, 0.0f  // Top-back
	};

	// Define the indices for the cube
	GLuint indices[] = {
		// Back face
		0, 1, 2, // First triangle
		0, 2, 3, // Second triangle
		// Front face
		4, 5, 6,
		4, 6, 7,
		// Left face
		8, 9, 10,
		8, 10, 11,
		// Right face
		12, 13, 14,
		12, 14, 15,
		// Bottom face
		16, 17, 18,
		16, 18, 19,
		// Top face
		20, 21, 22,
		20, 22, 23,
	};

	// Generate and bind the VAO for the cube
	glGenVertexArrays(1, &cubeVAO);
	glBindVertexArray(cubeVAO);

	// Generate and bind the VBO
	glGenBuffers(1, &cubeVBO);
	glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	// Generate and bind the EBO
	glGenBuffers(1, &cubeEBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cubeEBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

	// Set up the vertex attribute pointers
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// Unbind the VAO.
	glBindVertexArray(0);

}

void CreateMug(GLuint& mugVAO, GLuint& mugVBO, GLuint& mugEBO, float bottomRadius, float topRadius, float middleRadius, float height, int numSegments) {
	std::vector<GLfloat> vertices;
	std::vector<GLushort> indices;

	float angleStep = (2.0f * M_PI) / numSegments;
	float middleHeight = height / 3.0f;

	// Generate vertices
	for (int i = 0; i <= numSegments; ++i) {
		float angle = i * angleStep;

		for (int j = 0; j <= numSegments; ++j) {
			float currentHeight = height * ((float)j / numSegments);
			float currentRadius = bottomRadius;

			// Interpolate the radius for the current height to create the curvature
			if (currentHeight <= middleHeight) {
				currentRadius = bottomRadius + (middleRadius - bottomRadius) * (currentHeight / middleHeight);
			}
			else {
				currentRadius = middleRadius + (topRadius - middleRadius) * ((currentHeight - middleHeight) / (height - middleHeight));
			}

			vertices.push_back(currentRadius * cos(angle)); // X
			vertices.push_back(currentHeight - (height / 2.0f)); // Y (centered on the Y-axis)
			vertices.push_back(currentRadius * sin(angle)); // Z

			glm::vec3 normal = glm::normalize(glm::vec3(cos(angle), 0.0f, sin(angle)));
			vertices.push_back(normal.x); // Normal X
			vertices.push_back(normal.y); // Normal Y
			vertices.push_back(normal.z); // Normal Z

			vertices.push_back((float)i / numSegments); // U
			vertices.push_back((float)j / numSegments); // V
		}
	}

	// Generate indices
	int oneRingVertices = numSegments + 1;
	for (int i = 0; i < numSegments; ++i) {
		for (int j = 0; j < numSegments; ++j) {
			int current = i * oneRingVertices + j;
			int next = current + oneRingVertices;
			indices.push_back(current);
			indices.push_back(current + 1);
			indices.push_back(next + 1);

			indices.push_back(current);
			indices.push_back(next + 1);
			indices.push_back(next);
		}
	}

	//
	// Create buffers/arrays
	glGenVertexArrays(1, &mugVAO);
	glBindVertexArray(mugVAO);

	glGenBuffers(1, &mugVBO);
	glBindBuffer(GL_ARRAY_BUFFER, mugVBO);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(GLfloat), &vertices[0], GL_STATIC_DRAW);

	glGenBuffers(1, &mugEBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mugEBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLushort), &indices[0], GL_STATIC_DRAW);

	// Set the vertex attribute pointers
	// Vertex Positions
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)0);
	glEnableVertexAttribArray(0);
	// Vertex Normals
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	// Vertex Texture Coords
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// Unbind the VBO and VAO as a precaution
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

void CreateTorusSegment(GLuint& vao, GLuint& vbo, GLuint& ebo, int numMajor, int numMinor, float majorRadius, float minorRadius, float startAngle, float endAngle) {
	vector<GLfloat> vertices;
	vector<GLushort> indices;

	// Loop to build vertices and indices of the torus segment.
	for (int i = 0; i <= numMajor * (endAngle - startAngle) / (2 * M_PI); ++i) {
		float majorAngle = startAngle + 2 * M_PI * i / numMajor;
		float s0 = (float)i / numMajor;

		for (int j = 0; j <= numMinor; ++j) {
			float minorAngle = 2 * M_PI * j / numMinor;
			float t = (float)j / numMinor;

			// Calculate the position
			float x = (majorRadius + minorRadius * cos(minorAngle)) * cos(majorAngle);
			float y = (majorRadius + minorRadius * cos(minorAngle)) * sin(majorAngle);
			float z = minorRadius * sin(minorAngle);

			// Normal calculation
			glm::vec3 center = glm::vec3(majorRadius * cos(majorAngle), majorRadius * sin(majorAngle), 0.0f); // Center of the minor circle
			glm::vec3 position = glm::vec3(x, y, z); // Current vertex position
			glm::vec3 normal = glm::normalize(position - center); // Normal is the normalized vector from the center to the position

			// Add position
			vertices.push_back(x);
			vertices.push_back(y);
			vertices.push_back(z);

			// Add normal
			vertices.push_back(normal.x);
			vertices.push_back(normal.y);
			vertices.push_back(normal.z);

			// Add texture coordinates
			vertices.push_back(s0); // s texture coordinate
			vertices.push_back(t);  // t texture coordinate

			// Determine indices for the strip
			int nextMajor = (i + 1) % numMajor;
			int nextMinor = (j + 1) % numMinor;
			indices.push_back(i * (numMinor + 1) + j);
			indices.push_back(nextMajor * (numMinor + 1) + j);
			indices.push_back(i * (numMinor + 1) + nextMinor);
			indices.push_back(nextMajor * (numMinor + 1) + nextMinor);
		}
	}

	numVerticesTorus = indices.size();
	GLsizei stride = (8) * sizeof(float); // 3 for position, 3 for normal, 2 for texture

	// Generate and bind the VAO and VBO for the torus
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	glGenBuffers(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(GLfloat), vertices.data(), GL_STATIC_DRAW);

	glGenBuffers(1, &ebo);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLushort), indices.data(), GL_STATIC_DRAW);

	// Position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
	glEnableVertexAttribArray(0);

	// Normal attribute
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	// Texture attribute
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);

	glBindBuffer(GL_ARRAY_BUFFER, 0); // unbind vbo
	glBindVertexArray(0); // unbind VAO
}

// Create the vertices for all of our different shapes
void CreateVertices() {
	//////////////////////////////
	// Create the bottom plane before other objects
	CreateBasePlane(planeVAO, planeVBO, planeEBO);

	// Create book planes
	GLfloat bookWidth = 2.1f;
	GLfloat bookHeight = 1.1f;
	GLfloat bookDepth = -0.2f; 

	CreateBookPlane(leftBookVAO, leftBookVBO, leftBookEBO, bookWidth, bookHeight, bookDepth, true);
	CreateBookPlane(rightBookVAO, rightBookVBO, rightBookEBO, bookWidth, bookHeight, bookDepth, false);

	////////////////////////////////
	// Creating a cylinder for candle
	float candleRadius = 0.80f;
	float candleHeight = 1.6f;
	int candleNumSegments = 32;

	CreateCylinder(cylinderVAO, cylinderVBO, cylinderEBO, candleRadius, candleHeight, candleNumSegments);

	////////////////////
	// Mug creation call
	float mugBottomRadius = 1.1f;
	float mugTopRadius = 0.90f;
	float mugMiddleRadius = 1.20f;
	float mugHeight = 1.8f;
	int mugNumSegments = 32;

	CreateMug(mugVAO, mugVBO, mugEBO, mugBottomRadius, mugTopRadius, mugMiddleRadius, mugHeight, mugNumSegments);

	///////////////////////////////////////////////////////////
	// Torus creation
	// Create the torus for the handle and the top of our cup
	CreateTorusSegment(handleTorusVAO, handleTorusVBO, handleTorusEBO, 30, 15, .95f, 0.1f, 0, M_PI);
	CreateTorusSegment(topTorusVAO, topTorusVBO, topTorusEBO, 30, 15, .90f, 0.1f, 0, 2 * M_PI);

	////////////////
	// Create Cube
	CreateCube(cubeVAO, cubeVBO, cubeEBO);
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
	static const float cameraSpeed = 2.5f;

	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		gCamera.ProcessKeyboard(LEFT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		gCamera.ProcessKeyboard(UP, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		gCamera.ProcessKeyboard(DOWN, gDeltaTime);

	// Toggle between perspective and orthographic projection
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
		isPerspective = !isPerspective;
		// Wait a bit to avoid toggling too fast
		glfwWaitEventsTimeout(0.15);
	}
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

// Initialize GLFW, GLEW, and create a window
bool Initialize(GLFWwindow** window)
{
	// Initialize GLFW
	if (!glfwInit())
		return false;

	*window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
	if (!*window)
	{
		glfwTerminate();
		return false;
	}

	// Make the window's context current
	glfwMakeContextCurrent(*window);

	// Set GLFW callbacks
	glfwSetFramebufferSizeCallback(*window, UResizeWindow);
	glfwSetCursorPosCallback(*window, UMousePositionCallback);
	glfwSetScrollCallback(*window, UMouseScrollCallback);
	glfwSetMouseButtonCallback(*window, UMouseButtonCallback);
	glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// Initialize GLEW
	glewExperimental = GL_TRUE;
	if (glewInit() != GLEW_OK)
	{
		std::cerr << "Failed to initialize GLEW." << std::endl;
		return false;
	}

	// Create vertices for objects
	CreateVertices();

	return true;
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
	if (gFirstMouse)
	{
		gLastX = xpos;
		gLastY = ypos;
		gFirstMouse = false;
	}

	float xoffset = xpos - gLastX;
	float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

	gLastX = xpos;
	gLastY = ypos;

	gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
	gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
	switch (button)
	{
	case GLFW_MOUSE_BUTTON_LEFT:
	{
		if (action == GLFW_PRESS)
			cout << "Left mouse button pressed" << endl;
		else
			cout << "Left mouse button released" << endl;
	}
	break;

	case GLFW_MOUSE_BUTTON_MIDDLE:
	{
		if (action == GLFW_PRESS)
			cout << "Middle mouse button pressed" << endl;
		else
			cout << "Middle mouse button released" << endl;
	}
	break;

	case GLFW_MOUSE_BUTTON_RIGHT:
	{
		if (action == GLFW_PRESS)
			cout << "Right mouse button pressed" << endl;
		else
			cout << "Right mouse button released" << endl;
	}
	break;

	default:
		cout << "Unhandled mouse button event" << endl;
		break;
	}
}


int main(void)
{
	/* Initialize the library and create a window */
	if (!Initialize(&gWindow))
	{
		std::cerr << "Initialization failed." << std::endl;
		glfwTerminate();
		return -1;
	}

	// Create vertices for objects
	CreateVertices();

	// Create the shader program
	if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
		return EXIT_FAILURE;

	// Load our textures
	const char* textureFilenames[] = { "../images/brown-mug.png", "../images/mugblue.png",  "../images/black-texture.png", "../images/bookleft.png", "../images/wood.png", "../images/glass.png", "../images/bookright.png"};
	GLuint textureIDs[7];// Array to hold texture ID

	// Loop to load textures
	for (int i = 0; i < 7; ++i) {
		if (!UCreateTexture(textureFilenames[i], textureIDs[i])) {
			cout << "Failed to load texture " << textureFilenames[i] << endl;
			return EXIT_FAILURE;
		}
	}

	/* Loop until the user closes the window */
	while (!glfwWindowShouldClose(gWindow))
	{
		// per-frame time logic
		float currentFrame = glfwGetTime();
		gDeltaTime = currentFrame - gLastFrame;
		gLastFrame = currentFrame;

		// input
		UProcessInput(gWindow);

		// Draw primitives
		draw(gWindow, glfwGetTime(), textureIDs);

		/* Swap front and back buffers */
		glfwSwapBuffers(gWindow); // VSync operation

		/* Poll for and process events */
		glfwPollEvents(); // Detect keyboard and mouse input
	}

	glfwTerminate();
	return 0;
}